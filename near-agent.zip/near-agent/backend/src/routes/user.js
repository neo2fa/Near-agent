import express from 'express';
import { storageService } from '../services/storage.service.js';
import { nearService } from '../services/near.service.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

// Get user balance
router.get('/balance/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const balance = await nearService.getBalance(accountId);
    res.json(balance);
  } catch (error) {
    logger.error('Get balance error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get transaction history
router.get('/history/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const limit = parseInt(req.query.limit) || 50;
    
    const history = await storageService.getTransactionHistory(accountId, limit);
    res.json(history);
  } catch (error) {
    logger.error('Get history error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get user stats
router.get('/stats/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const stats = await storageService.getStats(accountId);
    res.json(stats);
  } catch (error) {
    logger.error('Get stats error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get dashboard data (combined)
router.get('/dashboard/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;

    const [balance, history, stats, config] = await Promise.all([
      nearService.getBalance(accountId),
      storageService.getTransactionHistory(accountId, 10),
      storageService.getStats(accountId),
      storageService.getUserConfig(accountId)
    ]);

    res.json({
      balance,
      recentTransactions: history,
      stats,
      agentStatus: {
        enabled: config?.enabled || false,
        rules: config?.rules || null
      }
    });
  } catch (error) {
    logger.error('Get dashboard error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Delete user data
router.delete('/data/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    await storageService.deleteUserData(accountId);
    res.json({ success: true, message: 'User data deleted' });
  } catch (error) {
    logger.error('Delete data error:', error);
    res.status(500).json({ error: error.message });
  }
});

export const userRouter = router;
