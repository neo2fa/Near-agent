import express from 'express';
import { agentEngine } from '../services/agent.engine.js';
import { storageService } from '../services/storage.service.js';
import { groqService } from '../services/groq.service.js';
import { logger } from '../utils/logger.js';

const router = express.Router();

// Enable agent
router.post('/enable', async (req, res) => {
  try {
    const { accountId, rules } = req.body;

    if (!accountId || !rules) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const result = await agentEngine.enableAgent(accountId, rules);
    res.json(result);
  } catch (error) {
    logger.error('Enable agent error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Disable agent
router.post('/disable', async (req, res) => {
  try {
    const { accountId } = req.body;

    if (!accountId) {
      return res.status(400).json({ error: 'Missing accountId' });
    }

    const result = await agentEngine.disableAgent(accountId);
    res.json(result);
  } catch (error) {
    logger.error('Disable agent error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get agent status
router.get('/status/:accountId', async (req, res) => {
  try {
    const { accountId } = req.params;
    const config = await storageService.getUserConfig(accountId);

    if (!config) {
      return res.json({ enabled: false, configured: false });
    }

    res.json({
      enabled: config.enabled,
      configured: true,
      rules: config.rules,
      createdAt: config.createdAt,
      lastUpdated: config.lastUpdated
    });
  } catch (error) {
    logger.error('Get status error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Update rules
router.put('/rules', async (req, res) => {
  try {
    const { accountId, rules } = req.body;

    if (!accountId || !rules) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    // Validate rules
    agentEngine.validateRules(rules);

    await storageService.updateUserConfig(accountId, {
      rules,
      lastUpdated: new Date().toISOString()
    });

    res.json({ success: true });
  } catch (error) {
    logger.error('Update rules error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get market analysis
router.get('/market-analysis', async (req, res) => {
  try {
    const analysis = await groqService.analyzeMarket();
    res.json(analysis);
  } catch (error) {
    logger.error('Market analysis error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Manual trigger (for testing)
router.post('/trigger', async (req, res) => {
  try {
    const { accountId } = req.body;

    if (!accountId) {
      return res.status(400).json({ error: 'Missing accountId' });
    }

    const config = await storageService.getUserConfig(accountId);
    if (!config) {
      return res.status(404).json({ error: 'User not configured' });
    }

    // Force process this user
    await agentEngine.processUser(config);

    res.json({ success: true, message: 'Agent triggered manually' });
  } catch (error) {
    logger.error('Manual trigger error:', error);
    res.status(500).json({ error: error.message });
  }
});

export const agentRouter = router;
