import * as nearAPI from 'near-api-js';
import { logger } from '../utils/logger.js';

const { connect, keyStores, KeyPair, utils } = nearAPI;

class NearService {
  constructor() {
    this.near = null;
    this.account = null;
    this.contract = null;
  }

  async initialize() {
    try {
      const networkId = process.env.NEAR_NETWORK || 'testnet';
      const accountId = process.env.NEAR_ACCOUNT_ID;
      const privateKey = process.env.NEAR_PRIVATE_KEY;

      if (!accountId || !privateKey) {
        throw new Error('NEAR credentials not configured');
      }

      // Configure NEAR connection
      const keyStore = new keyStores.InMemoryKeyStore();
      const keyPair = KeyPair.fromString(privateKey);
      await keyStore.setKey(networkId, accountId, keyPair);

      const config = {
        networkId,
        keyStore,
        nodeUrl: `https://rpc.${networkId}.near.org`,
        walletUrl: `https://wallet.${networkId}.near.org`,
        helperUrl: `https://helper.${networkId}.near.org`,
        explorerUrl: `https://explorer.${networkId}.near.org`,
      };

      this.near = await connect(config);
      this.account = await this.near.account(accountId);
      
      logger.info(`Connected to NEAR ${networkId} as ${accountId}`);
      return true;
    } catch (error) {
      logger.error('NEAR initialization failed:', error);
      throw error;
    }
  }

  async getBalance(accountId) {
    try {
      const account = await this.near.account(accountId);
      const balance = await account.getAccountBalance();
      
      return {
        total: utils.format.formatNearAmount(balance.total),
        available: utils.format.formatNearAmount(balance.available),
        stateStaked: utils.format.formatNearAmount(balance.stateStaked),
        staked: utils.format.formatNearAmount(balance.staked)
      };
    } catch (error) {
      logger.error(`Failed to get balance for ${accountId}:`, error);
      throw error;
    }
  }

  async swapNearToStablecoin(amount, receiverId) {
    try {
      // Convert NEAR amount to yoctoNEAR
      const amountInYocto = utils.format.parseNearAmount(amount.toString());
      
      logger.info(`Swapping ${amount} NEAR to stablecoin for ${receiverId}`);

      // In production, this would interact with REF Finance or another DEX
      // For demo, we simulate the swap
      const result = await this.simulateSwap(amountInYocto, receiverId);
      
      logger.info(`Swap successful: ${result.txHash}`);
      return result;
    } catch (error) {
      logger.error('Swap failed:', error);
      throw error;
    }
  }

  async simulateSwap(amountInYocto, receiverId) {
    // Simulate swap transaction
    // In production, integrate with REF Finance:
    // https://guide.ref.finance/developers/contracts
    
    const txHash = `swap_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const usdcAmount = parseFloat(utils.format.formatNearAmount(amountInYocto)) * 5.5; // Assume 1 NEAR = 5.5 USDC
    
    return {
      success: true,
      txHash,
      nearAmount: utils.format.formatNearAmount(amountInYocto),
      usdcAmount: usdcAmount.toFixed(2),
      timestamp: new Date().toISOString()
    };
  }

  async transferNear(receiverId, amount) {
    try {
      const amountInYocto = utils.format.parseNearAmount(amount.toString());
      
      const result = await this.account.sendMoney(
        receiverId,
        amountInYocto
      );
      
      logger.info(`Transferred ${amount} NEAR to ${receiverId}`);
      return result;
    } catch (error) {
      logger.error('Transfer failed:', error);
      throw error;
    }
  }

  async callContract(contractId, methodName, args = {}, gas = '300000000000000', deposit = '0') {
    try {
      const result = await this.account.functionCall({
        contractId,
        methodName,
        args,
        gas,
        attachedDeposit: deposit
      });
      
      return result;
    } catch (error) {
      logger.error(`Contract call failed (${methodName}):`, error);
      throw error;
    }
  }

  async viewContract(contractId, methodName, args = {}) {
    try {
      const result = await this.account.viewFunction({
        contractId,
        methodName,
        args
      });
      
      return result;
    } catch (error) {
      logger.error(`Contract view failed (${methodName}):`, error);
      throw error;
    }
  }

  formatNearAmount(yoctoNear) {
    return utils.format.formatNearAmount(yoctoNear);
  }

  parseNearAmount(nearAmount) {
    return utils.format.parseNearAmount(nearAmount);
  }
}

export const nearService = new NearService();
