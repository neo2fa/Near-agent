import { nearService } from './near.service.js';
import { groqService } from './groq.service.js';
import { storageService } from './storage.service.js';
import { logger } from '../utils/logger.js';

class AgentEngine {
  constructor() {
    this.isProcessing = false;
  }

  async processAllUsers() {
    if (this.isProcessing) {
      logger.info('Agent already processing, skipping...');
      return;
    }

    this.isProcessing = true;

    try {
      const activeUsers = await storageService.getActiveUsers();
      logger.info(`Processing ${activeUsers.length} active users`);

      for (const user of activeUsers) {
        try {
          await this.processUser(user);
        } catch (error) {
          logger.error(`Failed to process user ${user.accountId}:`, error);
          // Continue with next user
        }
      }
    } finally {
      this.isProcessing = false;
    }
  }

  async processUser(user) {
    logger.info(`Processing user: ${user.accountId}`);

    // Get current balance
    const balance = await nearService.getBalance(user.accountId);
    
    // Get transaction history
    const history = await storageService.getTransactionHistory(user.accountId);
    
    // Check if enough time has passed since last save
    if (!this.shouldCheckUser(user, history)) {
      logger.info(`Skipping ${user.accountId} - too soon since last save`);
      return;
    }

    // Get AI decision
    const decision = await groqService.analyzeAndDecide(
      balance,
      user.rules,
      history
    );

    logger.info(`AI Decision for ${user.accountId}:`, decision);

    // Execute if AI recommends saving
    if (decision.shouldSave && decision.amount > 0) {
      await this.executeSave(user, decision, balance);
    } else {
      logger.info(`Not saving for ${user.accountId}: ${decision.reason}`);
    }
  }

  shouldCheckUser(user, history) {
    if (history.length === 0) {
      return true; // First time
    }

    const lastSave = new Date(history[0].timestamp);
    const now = new Date();
    const hoursSince = (now - lastSave) / (1000 * 60 * 60);

    const minHours = {
      'daily': 24,
      'weekly': 168,
      'bi-weekly': 336,
      'monthly': 720
    };

    const required = minHours[user.rules.frequency] || 24;
    return hoursSince >= required;
  }

  async executeSave(user, decision, currentBalance) {
    try {
      logger.info(`Executing save for ${user.accountId}: ${decision.amount} NEAR`);

      // Perform the swap
      const swapResult = await nearService.swapNearToStablecoin(
        decision.amount,
        user.accountId
      );

      // Record transaction
      await storageService.recordTransaction({
        accountId: user.accountId,
        type: 'auto_save',
        nearAmount: decision.amount,
        usdcAmount: swapResult.usdcAmount,
        txHash: swapResult.txHash,
        aiDecision: decision,
        balanceBefore: currentBalance.available,
        timestamp: new Date().toISOString()
      });

      // Send notification (implement email/push later)
      logger.info(`✅ Save completed for ${user.accountId}`);

      return swapResult;
    } catch (error) {
      logger.error(`Save execution failed for ${user.accountId}:`, error);
      
      // Record failed transaction
      await storageService.recordTransaction({
        accountId: user.accountId,
        type: 'failed_save',
        nearAmount: decision.amount,
        error: error.message,
        aiDecision: decision,
        timestamp: new Date().toISOString()
      });

      throw error;
    }
  }

  async quickCheck() {
    // Quick check for urgent saves (high volatility, etc)
    logger.info('Running quick check...');
    
    const urgentUsers = await storageService.getUrgentUsers();
    
    for (const user of urgentUsers) {
      try {
        await this.processUser(user);
      } catch (error) {
        logger.error(`Quick check failed for ${user.accountId}:`, error);
      }
    }
  }

  async enableAgent(accountId, rules) {
    try {
      logger.info(`Enabling agent for ${accountId}`);

      // Validate rules
      this.validateRules(rules);

      // Save user configuration
      await storageService.saveUserConfig(accountId, {
        rules,
        enabled: true,
        createdAt: new Date().toISOString(),
        lastUpdated: new Date().toISOString()
      });

      logger.info(`Agent enabled for ${accountId}`);
      return { success: true };
    } catch (error) {
      logger.error(`Failed to enable agent for ${accountId}:`, error);
      throw error;
    }
  }

  async disableAgent(accountId) {
    try {
      logger.info(`Disabling agent for ${accountId}`);

      await storageService.updateUserConfig(accountId, {
        enabled: false,
        lastUpdated: new Date().toISOString()
      });

      logger.info(`Agent disabled for ${accountId}`);
      return { success: true };
    } catch (error) {
      logger.error(`Failed to disable agent for ${accountId}:`, error);
      throw error;
    }
  }

  validateRules(rules) {
    const required = ['threshold', 'percentage', 'frequency'];
    
    for (const field of required) {
      if (!(field in rules)) {
        throw new Error(`Missing required field: ${field}`);
      }
    }

    if (rules.threshold <= 0) {
      throw new Error('Threshold must be positive');
    }

    if (rules.percentage <= 0 || rules.percentage > 100) {
      throw new Error('Percentage must be between 0 and 100');
    }

    const validFrequencies = ['daily', 'weekly', 'bi-weekly', 'monthly'];
    if (!validFrequencies.includes(rules.frequency)) {
      throw new Error('Invalid frequency');
    }
  }
}

export const agentEngine = new AgentEngine();
