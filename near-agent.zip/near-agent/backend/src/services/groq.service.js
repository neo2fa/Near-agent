import Groq from 'groq-sdk';
import { logger } from '../utils/logger.js';

class GroqService {
  constructor() {
    this.client = new Groq({
      apiKey: process.env.GROQ_API_KEY
    });
  }

  async analyzeAndDecide(userBalance, rules, history = []) {
    try {
      const prompt = this.buildPrompt(userBalance, rules, history);
      
      const completion = await this.client.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are an AI financial advisor for a NEAR blockchain auto-savings agent. Analyze user balance and rules, then decide if and how much to save. Respond in JSON format only.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        model: 'llama-3.1-70b-versatile',
        temperature: 0.3,
        max_tokens: 500,
        response_format: { type: 'json_object' }
      });

      const response = completion.choices[0]?.message?.content;
      const decision = JSON.parse(response);
      
      logger.info('AI Decision:', decision);
      return decision;
    } catch (error) {
      logger.error('Groq AI analysis failed:', error);
      
      // Fallback to rule-based decision
      return this.fallbackDecision(userBalance, rules);
    }
  }

  buildPrompt(userBalance, rules, history) {
    const lastSave = history.length > 0 
      ? new Date(history[0].timestamp).toISOString()
      : 'Never';
    
    const totalSaved = history.reduce((sum, tx) => sum + parseFloat(tx.amount), 0);

    return `
Analyze this user's savings situation:

Current NEAR Balance: ${userBalance.available} NEAR
Total Balance: ${userBalance.total} NEAR

User's Savings Rules:
- Threshold: Save when balance > ${rules.threshold} NEAR
- Percentage: Convert ${rules.percentage}% to stablecoin
- Frequency: ${rules.frequency}
- Min Amount: ${rules.minAmount || 1} NEAR
- Max Amount: ${rules.maxAmount || 1000} NEAR per transaction

Transaction History:
- Last Save: ${lastSave}
- Total Saved: ${totalSaved} NEAR
- Transaction Count: ${history.length}

Current Market Context:
- NEAR Price: ~$5.50 (stable)
- Volatility: Low
- Gas Fees: Normal

Decision Required:
Should we execute a savings transaction now?

Respond with JSON:
{
  "shouldSave": true/false,
  "amount": <number in NEAR>,
  "reason": "<brief explanation>",
  "confidence": <0-100>,
  "timing": "immediate/wait_1h/wait_24h",
  "marketAnalysis": "<brief market context>"
}

Consider:
1. Is balance above threshold?
2. Has enough time passed since last save?
3. Is the amount within min/max limits?
4. Are market conditions favorable?
5. Will user have enough NEAR left for gas fees?
`;
  }

  fallbackDecision(userBalance, rules) {
    const available = parseFloat(userBalance.available);
    const threshold = parseFloat(rules.threshold);
    const percentage = parseFloat(rules.percentage) / 100;
    
    if (available <= threshold) {
      return {
        shouldSave: false,
        amount: 0,
        reason: 'Balance below threshold',
        confidence: 100,
        timing: 'wait_24h',
        marketAnalysis: 'Fallback rule-based decision'
      };
    }

    const saveAmount = available * percentage;
    const minAmount = parseFloat(rules.minAmount || 1);
    const maxAmount = parseFloat(rules.maxAmount || 1000);
    
    const finalAmount = Math.max(minAmount, Math.min(saveAmount, maxAmount));
    
    // Keep at least 2 NEAR for gas
    if (available - finalAmount < 2) {
      return {
        shouldSave: false,
        amount: 0,
        reason: 'Not enough NEAR left for gas fees',
        confidence: 100,
        timing: 'wait_24h',
        marketAnalysis: 'Fallback rule-based decision'
      };
    }

    return {
      shouldSave: true,
      amount: finalAmount,
      reason: 'Balance above threshold, conditions met',
      confidence: 85,
      timing: 'immediate',
      marketAnalysis: 'Fallback rule-based decision'
    };
  }

  async analyzeMarket() {
    try {
      const prompt = `
Analyze current NEAR Protocol market conditions:

Provide a brief market analysis including:
1. Overall market sentiment (bullish/bearish/neutral)
2. Volatility level (low/medium/high)
3. Recommendation for savings timing

Respond in JSON:
{
  "sentiment": "bullish/bearish/neutral",
  "volatility": "low/medium/high",
  "recommendation": "<brief advice>",
  "confidence": <0-100>
}
`;

      const completion = await this.client.chat.completions.create({
        messages: [
          {
            role: 'system',
            content: 'You are a crypto market analyst specializing in NEAR Protocol.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        model: 'llama-3.1-70b-versatile',
        temperature: 0.5,
        max_tokens: 300,
        response_format: { type: 'json_object' }
      });

      const response = completion.choices[0]?.message?.content;
      return JSON.parse(response);
    } catch (error) {
      logger.error('Market analysis failed:', error);
      return {
        sentiment: 'neutral',
        volatility: 'medium',
        recommendation: 'Continue with regular savings schedule',
        confidence: 50
      };
    }
  }
}

export const groqService = new GroqService();
