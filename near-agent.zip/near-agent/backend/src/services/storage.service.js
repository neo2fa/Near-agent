import { logger } from '../utils/logger.js';

// In-memory storage (replace with database in production)
class StorageService {
  constructor() {
    this.users = new Map(); // accountId -> user config
    this.transactions = new Map(); // accountId -> transactions[]
  }

  async saveUserConfig(accountId, config) {
    this.users.set(accountId, {
      accountId,
      ...config
    });
    logger.info(`Saved config for ${accountId}`);
    return true;
  }

  async updateUserConfig(accountId, updates) {
    const existing = this.users.get(accountId);
    if (!existing) {
      throw new Error('User not found');
    }

    this.users.set(accountId, {
      ...existing,
      ...updates
    });
    
    logger.info(`Updated config for ${accountId}`);
    return true;
  }

  async getUserConfig(accountId) {
    return this.users.get(accountId) || null;
  }

  async getActiveUsers() {
    const active = [];
    
    for (const [accountId, config] of this.users.entries()) {
      if (config.enabled) {
        active.push(config);
      }
    }
    
    return active;
  }

  async getUrgentUsers() {
    // Users who need immediate attention
    // For now, return empty (implement based on volatility alerts)
    return [];
  }

  async recordTransaction(transaction) {
    const accountId = transaction.accountId;
    
    if (!this.transactions.has(accountId)) {
      this.transactions.set(accountId, []);
    }
    
    const txs = this.transactions.get(accountId);
    txs.unshift(transaction); // Add to beginning
    
    // Keep last 100 transactions
    if (txs.length > 100) {
      txs.pop();
    }
    
    logger.info(`Recorded transaction for ${accountId}`);
    return true;
  }

  async getTransactionHistory(accountId, limit = 50) {
    const txs = this.transactions.get(accountId) || [];
    return txs.slice(0, limit);
  }

  async getStats(accountId) {
    const txs = this.transactions.get(accountId) || [];
    const successfulSaves = txs.filter(tx => tx.type === 'auto_save');
    
    const totalNearSaved = successfulSaves.reduce((sum, tx) => {
      return sum + parseFloat(tx.nearAmount || 0);
    }, 0);
    
    const totalUsdcReceived = successfulSaves.reduce((sum, tx) => {
      return sum + parseFloat(tx.usdcAmount || 0);
    }, 0);
    
    const lastSave = successfulSaves.length > 0 
      ? successfulSaves[0].timestamp 
      : null;
    
    return {
      totalSaves: successfulSaves.length,
      totalNearSaved: totalNearSaved.toFixed(2),
      totalUsdcReceived: totalUsdcReceived.toFixed(2),
      lastSave,
      avgSaveAmount: successfulSaves.length > 0 
        ? (totalNearSaved / successfulSaves.length).toFixed(2) 
        : 0
    };
  }

  async deleteUserData(accountId) {
    this.users.delete(accountId);
    this.transactions.delete(accountId);
    logger.info(`Deleted all data for ${accountId}`);
    return true;
  }

  // Mock data for demo
  async initializeDemoData() {
    // Add sample user
    await this.saveUserConfig('demo.testnet', {
      rules: {
        threshold: 10,
        percentage: 20,
        frequency: 'daily',
        minAmount: 1,
        maxAmount: 100
      },
      enabled: true,
      createdAt: new Date().toISOString(),
      lastUpdated: new Date().toISOString()
    });

    // Add sample transactions
    const sampleTxs = [
      {
        accountId: 'demo.testnet',
        type: 'auto_save',
        nearAmount: 3.5,
        usdcAmount: 19.25,
        txHash: 'demo_tx_1',
        balanceBefore: 15.2,
        timestamp: new Date(Date.now() - 86400000).toISOString() // 1 day ago
      },
      {
        accountId: 'demo.testnet',
        type: 'auto_save',
        nearAmount: 4.2,
        usdcAmount: 23.10,
        txHash: 'demo_tx_2',
        balanceBefore: 18.5,
        timestamp: new Date(Date.now() - 172800000).toISOString() // 2 days ago
      }
    ];

    for (const tx of sampleTxs) {
      await this.recordTransaction(tx);
    }

    logger.info('Demo data initialized');
  }
}

export const storageService = new StorageService();

// Initialize demo data
storageService.initializeDemoData();
