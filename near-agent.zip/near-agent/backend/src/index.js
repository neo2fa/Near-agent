import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import cron from 'node-cron';
import { agentRouter } from './routes/agent.js';
import { userRouter } from './routes/user.js';
import { nearService } from './services/near.service.js';
import { agentEngine } from './services/agent.engine.js';
import { logger } from './utils/logger.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());

// Health check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: 'NEAR Agent Backend',
    timestamp: new Date().toISOString() 
  });
});

// Routes
app.use('/api/agent', agentRouter);
app.use('/api/user', userRouter);

// Initialize NEAR
async function initializeServices() {
  try {
    await nearService.initialize();
    logger.info('NEAR service initialized');
    
    // Start the agent engine cron job
    startAgentCron();
    logger.info('Agent cron job started');
  } catch (error) {
    logger.error('Failed to initialize services:', error);
    process.exit(1);
  }
}

// Cron job to check and execute savings
function startAgentCron() {
  // Run every hour
  cron.schedule('0 * * * *', async () => {
    logger.info('Running agent cron job...');
    try {
      await agentEngine.processAllUsers();
      logger.info('Agent cron job completed');
    } catch (error) {
      logger.error('Agent cron job failed:', error);
    }
  });
  
  // Also run every 5 minutes for more frequent checks
  cron.schedule('*/5 * * * *', async () => {
    logger.info('Running quick agent check...');
    try {
      await agentEngine.quickCheck();
    } catch (error) {
      logger.error('Quick check failed:', error);
    }
  });
}

// Error handling middleware
app.use((err, req, res, next) => {
  logger.error('Express error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Start server
app.listen(PORT, async () => {
  logger.info(`🚀 NEAR Agent Backend running on port ${PORT}`);
  await initializeServices();
});

export default app;
